SELECT * FROM ROOM;
SELECT * FROM ROOMOPTION;
SELECT * FROM ROOM R, ROOMOPTION O WHERE R.R_NO = O.R_NO;
delete from room where r_no != -1;
CREATE SEQUENCE R_NO_SQ
        NOCACHE
        NOCYCLE
        MAXVALUE 1000;
drop sequence R_NO_SQ;
INSERT INTO ROOM (R_NO, R_NAME, R_IMAGE, R_PPR, R_PPH, R_STATUS)
            VALUES(R_NO_SQ.NEXTVAL, '805호', '배경.jpg', '4', '2000', 1);

-- OPTION WI-FI(0 없음 1- 100M, 2-1G광랜) TV(1-프로젝터, 2-TV 3- 둘다), PRINT(1-BLACK, 2-COLOR), CHAIR(1 목재 테이블 2-+쇼파)
INSERT INTO ROOMOPTION (R_NO, RO_AIR, RO_CHAIR, RO_PRINT, RO_SMOKE, RO_PC, RO_TV, RO_WIFI, RO_BOARD)
                VALUES (R_NO_SQ.CURRVAL , 1, 1, 1, 0, 1, 0, 1, 1);
SELECT * FROM ROOM;       
            
COMMIT;
select R_NO_SQ.currval from dual;
INSERT INTO ROOMOPTION (R_NO, RO_AIR, RO_CHAIR, RO_PRINT, RO_SMOKE, RO_PC, RO_TV, RO_WIFI, RO_BOARD)
                VALUES ((SELECT MAX(R_NO) FROM ROOM), 1, 1, 1, 0, 1, 0, 1, 1);
CREATE SEQUENCE XX;
select xx.currval from dual;
SELECT MAX(R_NO) FROM ROOM;
